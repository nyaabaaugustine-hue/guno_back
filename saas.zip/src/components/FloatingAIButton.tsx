'use client'

import { useState, useRef, useEffect } from 'react'
import { Bot, X, Send, Loader2, Sparkles, ChevronDown, Database, Cpu } from 'lucide-react'

interface Message {
  role: 'user' | 'assistant'
  content: string
  sql?: string
  cached?: boolean
}

const suggestedQueries = [
  'How many clients do I have?',
  'Show me all clients',
  'How many returns are completed?',
  'Returns in review',
  'Give me a full summary',
  'List team members',
]

export default function FloatingAIButton() {
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content:
        '👋 Hi! I can answer questions about your database. Try asking about clients, returns, documents, or team members.',
    },
  ])
  const [loading, setLoading] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Focus input when opened
  useEffect(() => {
    if (open) inputRef.current?.focus()
  }, [open])

  const handleSubmit = async (query?: string) => {
    const q = query || input
    if (!q.trim() || loading) return

    setShowSuggestions(false)
    setInput('')
    setMessages((prev) => [...prev, { role: 'user', content: q }])
    setLoading(true)

    try {
      const res = await fetch('/api/ai/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q }),
      })

      const data = await res.json()

      if (data.error) {
        setMessages((prev) => [
          ...prev,
          {
            role: 'assistant',
            content: `❌ ${data.error}`,
          },
        ])
      } else {
        const responseText = data.sql
          ? `${data.response}\n\n${data.cached ? '⚡ _Cached result_' : ''}`
          : data.response

        setMessages((prev) => [
          ...prev,
          {
            role: 'assistant',
            content: responseText,
            sql: data.sql,
            cached: data.cached,
          },
        ])
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: "❌ Sorry, I couldn't reach the server. Please try again.",
        },
      ])
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-juno-dark-green hover:bg-juno-mid-green text-white rounded-full shadow-lg shadow-juno-dark-green/30 flex items-center justify-center transition-all duration-300 hover:scale-110 active:scale-95 group"
        aria-label="AI Assistant"
      >
        {open ? (
          <X className="w-6 h-6" />
        ) : (
          <div className="relative">
            <Bot className="w-6 h-6" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-juno-green rounded-full animate-pulse" />
          </div>
        )}
      </button>

      {/* Chat panel */}
      {open && (
        <div className="fixed bottom-24 right-6 z-50 w-[380px] max-w-[calc(100vw-48px)] h-[560px] max-h-[calc(100vh-160px)] bg-white rounded-2xl shadow-2xl border border-dark-100 flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 duration-200">
          {/* Header */}
          <div className="flex items-center gap-3 px-5 py-4 border-b border-dark-100 bg-gradient-to-r from-juno-dark-green to-juno-mid-green">
            <div className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold text-white">Database AI</h3>
              <div className="flex items-center gap-1.5 mt-0.5">
                <Database className="w-3 h-3 text-white/70 shrink-0" />
                <span className="text-[11px] text-white/70 truncate">Connected to Neon</span>
              </div>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="p-1.5 text-white/70 hover:text-white rounded-lg hover:bg-white/10 transition-colors shrink-0"
            >
              <ChevronDown className="w-4 h-4" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
            {messages.map((msg, i) => (
              <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                {msg.role === 'assistant' && (
                  <div className="w-7 h-7 rounded-full bg-juno-light-green flex items-center justify-center shrink-0 mt-0.5">
                    <Cpu className="w-3.5 h-3.5 text-juno-dark-green" />
                  </div>
                )}
                <div
                  className={`max-w-[85%] ${
                    msg.role === 'user'
                      ? 'bg-juno-dark-green text-white rounded-2xl rounded-br-md px-4 py-2.5'
                      : 'text-dark-700'
                  }`}
                >
                  <div className="text-sm leading-relaxed whitespace-pre-line">
                    {msg.content}
                  </div>
                  {msg.sql && (
                    <div className="mt-2 pt-2 border-t border-dark-100/50">
                      <code className="text-[10px] font-mono text-dark-400 block truncate">
                        🗄️ {msg.sql}
                      </code>
                    </div>
                  )}
                  {msg.cached && (
                    <div className="mt-1 flex items-center gap-1">
                      <span className="text-[10px] text-dark-400">⚡ from cache</span>
                    </div>
                  )}
                </div>
                {msg.role === 'user' && (
                  <div className="w-7 h-7 rounded-full bg-juno-dark-green flex items-center justify-center shrink-0 mt-0.5">
                    <span className="text-white text-[10px] font-semibold">U</span>
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="flex gap-3">
                <div className="w-7 h-7 rounded-full bg-juno-light-green flex items-center justify-center shrink-0">
                  <Cpu className="w-3.5 h-3.5 text-juno-dark-green" />
                </div>
                <div className="flex items-center gap-2 text-sm text-dark-400">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Querying database...
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Suggested queries */}
          {showSuggestions && messages.length <= 1 && (
            <div className="px-4 pb-2">
              <p className="text-[11px] font-medium text-dark-400 uppercase tracking-wider mb-2">
                Try asking:
              </p>
              <div className="flex flex-wrap gap-1.5">
                {suggestedQueries.map((q) => (
                  <button
                    key={q}
                    onClick={() => handleSubmit(q)}
                    className="text-xs px-2.5 py-1.5 rounded-full bg-dark-50 text-dark-600 hover:bg-juno-light-green hover:text-juno-dark-green border border-dark-100 hover:border-juno-green/30 transition-all"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <div className="border-t border-dark-100 p-3">
            <form
              onSubmit={(e) => {
                e.preventDefault()
                handleSubmit()
              }}
              className="flex gap-2"
            >
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about your data..."
                className="flex-1 px-3.5 py-2.5 rounded-xl border-2 border-dark-200 bg-dark-50 text-sm text-dark-900 placeholder-dark-400 focus:outline-none focus:ring-2 focus:ring-juno-green/20 focus:border-juno-green transition-all"
                disabled={loading}
              />
              <button
                type="submit"
                disabled={!input.trim() || loading}
                className="w-10 h-10 bg-juno-dark-green hover:bg-juno-mid-green disabled:bg-dark-200 text-white rounded-xl flex items-center justify-center transition-all disabled:cursor-not-allowed"
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  )
}
